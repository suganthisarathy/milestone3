package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.SignUpDao;
import com.example.stockspring.model.User;

@Service
public class SignUpServiceImpl implements SignUpService {
	@Autowired
	public SignUpDao signUpDao;
	@Override
	public User insertUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		
	
	return  signUpDao.save(user);
		
	}
	@Override
	public List<User> getUserList() throws SQLException {
		// TODO Auto-generated method stub
		return  signUpDao.findAll();
	}

}
